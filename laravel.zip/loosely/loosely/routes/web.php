<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login','viewController@login');
Route::post('/login','databaseController@login');
//========================================================>
Route::get('/adminHome','viewController@adminHome');


//========================================================>
Route::get('/register','viewController@register');
Route::post('/submit','databaseController@register');
//====================StudentInfo======================================>
   Route::get('/studentMarks','databaseController@studentMarks');
   Route::post('/student','databaseController@student');
   Route::get('/studentInfo','databaseController@studentInfo');
//=======================>
   Route::get('/coursemanage','databaseController@manage');






   
   Route::get('/course','databaseController@course');
   Route::post('/course','databaseController@courses');

