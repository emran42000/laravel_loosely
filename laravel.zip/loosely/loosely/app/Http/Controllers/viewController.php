<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class viewController extends Controller
{
    //
//============login======================>

  public function login(){
		return view('/login');
	}

	public function register(){
		return view('/register');
	}

//==================adminHome================>

	public function adminHome(){
		return view('/adminHome');
	}

















}

      