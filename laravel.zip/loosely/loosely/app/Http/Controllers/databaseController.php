<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;

//==========================
use App\students;
use App\courses;
class databaseController extends Controller
{
    
  public function register(request $request)
     // public function store(request $request)

{

  
	//print_r($request->input());
	$name=$request->input('name');
	$password=$request->input('password');
	$email=$request->input('email');
	echo DB::insert('insert into users(id,name,email,password) value(?,?,?,?)',[null,$name,$email,$password]);

	return redirect('/login');
	// $data = DB::select("select * from users");
	// echo "<pre>";
	// print_r($data);

}

// ==================================================Login=====================================>>
     public function login(request $request)

       {
 	

		 	 $name=$request->input('name');
			 $password=$request->input('password');
			 $data = DB::select ('select id from users WHERE name=? and password=?',[$name,$password]);
					
								// echo "<pre>";
								//print_r($data);

			 if (count($data)) 
				 {
				 	// return redirect('/adminHome');
				 	return redirect('/adminHome');


				 }
			 else
			     {

			 	 return view('register');


			     	//return view('student');
			     }
	 }

	 //=====================Student======================================>
	 public function studentMarks(){
	 	return view('/student');
	 }
//======================marks===========================>

	 public function student(request $request)
		 {

            $name=$request->input('name');
					$studentId=$request->input('studentId');
					$marks=$request->input('marks');
					echo DB::insert('insert into students(id,name,studentId,marks) value(?,?,?,?)',[null,$name,$studentId,$marks]);




					return redirect('/studentMarks');


		 }

		 //===================StudentInfo======================>

public function studentInfo()
		    {
		    	$data['data'] = DB::table('students')->get();
		    	// echo "<pre>";
		    	// print_r($data)	;
		    	if (count($data)) {
		    		return view('studentInfo',$data);
		    	}
		    	else{
		    		echo "problems";
		    	}
		    	
		    }
//==================Course===============>
		    public function Course(){
   //$data = DB::select ('select id from users WHERE name=? and password=?',[$name,$password]);
		    	$data['data'] =DB::select('select *from students WHERE marks >50');
		    	return view('/course',$data);

		    }



//==============IF u think u can ==========================>

	public function courses(Request $request)
		 {

                    $courseName=$request->input('courseName');
					$studentId=$request->input('studentId');
				
					echo DB::insert('insert into courses(id,courseName,studentId) value(?,?,?)',[null,$courseName,$studentId]);
 
 

		 }


		 //=====================================>



public function manage(){
	

// $data['data'] =DB::select('select courses.*,students.name from courses join students on students.id = studentId')->get();
$products = DB::table('courses')
           ->join('students','students.id','=','courses.studentId')
           ->select('courses.*','students.name as name')
           ->get();


	           
	return view('/courseManage',['products'=>$products]);
	//return view('/course',$data);
}













}
